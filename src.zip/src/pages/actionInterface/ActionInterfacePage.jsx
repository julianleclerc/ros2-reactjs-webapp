// src/pages/actionInterface/ActionInterfacePage.jsx
import React from "react";
import PlannedActionPanel from '../../components/plannedActions/PlannedActionPanel.jsx';

const ActionInterfacePage = () => {
    return (
        <div className="app">
            <PlannedActionPanel />
            <div className="void-panel"> {/* Gray void section */}
                {/* Empty section */}
            </div>
        </div>
    );
};

export default ActionInterfacePage;
