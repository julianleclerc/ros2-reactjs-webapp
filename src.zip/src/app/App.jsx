import React, { useState } from "react";
import "./App.css";
import MenuPanel from "../components/menu/MenuPanel";
import ChatInterfacePage from "../pages/chatInterface/ChatInterfacePage";
import ActionInterfacePage from "../pages/actionInterface/ActionInterfacePage";

const App = () => {
    const [currentPage, setCurrentPage] = useState("ChatInterfacePage");

    const renderPage = () => {
        switch (currentPage) {
            case "ChatInterfacePage":
                return <ChatInterfacePage />;
            case "ActionInterfacePage":
                return <ActionInterfacePage />;
            default:
                return <ChatInterfacePage />;
        }
    };

    return (
        <div className="app">
            <MenuPanel setPage={setCurrentPage} />
            {renderPage()}
        </div>
    );
};

export default App;
